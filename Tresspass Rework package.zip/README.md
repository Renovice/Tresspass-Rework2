# Tresspass tweaks a mod for generally improving and making trespass more versatile
Main changes: Makes both corrupted and normal tresspass work the same way.

Tap shift to trigger a short forward dash just like corrupted dash from vanilla BUT for both trespass versions, both in corrupte and regular mode.
Hold shift to trigger a longer dash with an upward arc. Just like regular trespass but again available for both modes.

The mod also provides a toggle for a non cancellable mode where if u hold shift and the upward arc animation starts, it will not end until max duration is reached,  regardless if you let go of the shift key. 

Now features controller support through custom keybinds, which also allows custom ways of using the mod. For example, binding the mod to Mouse3 lets you hold that button and simply tap the utility skill button—you no longer need to hold the utility skill button itself. If you bind the mod to a different button, you can hold that button instead and press the utility skill button however you like. It will still trigger the “hold” effect as long as you are holding down your custom keybind.









# Changeolog 

ver 0.6.0:

-Added custom keybind/controller support.
-Replaced harmony patches with On.* Hooks.
-Added the mod's icon to the RiskOfOptions ingame config menu. 

ver 0.5.0: 

- initial release 

